const { initializeTestEnvironment, assertFails, assertSucceeds } = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;

before(async () => {
  testEnv = await initializeTestEnvironment({
    projectId: "demo-no-project",
    firestore: {
      host: "127.0.0.1",
      port: 8085,
      rules: fs.readFileSync("firestore.rules", "utf8")
    }
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("unauthenticated user cannot read crew entries", async () => {
  const unauthedDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthedDb.collection("lobbies/bhp/crew_entries").get());
});

test("unauthenticated user cannot create crew entry", async () => {
  const unauthedDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(
    unauthedDb.collection("lobbies/bhp/crew_entries").add({
      reportingDate: "2026-10-25",
      offDate: "2026-10-25",
      offTime: "06:52",
      status: "Working",
      room: "Availed",
      userId: "user123"
    })
  );
});

test("authenticated user can create valid crew entry", async () => {
  const authedDb = testEnv.authenticatedContext("user123").firestore();
  await assertSucceeds(
    authedDb.collection("lobbies/bhp/crew_entries").add({
      reportingDate: "2026-10-25",
      offDate: "2026-10-25",
      offTime: "06:52",
      onDate: "2026-10-25",
      onTime: "15:20",
      status: "Working",
      room: "Availed",
      userId: "user123",
      lobbyId: "bhp"
    })
  );
});

test("authenticated user cannot create crew entry with another user's ID", async () => {
  const authedDb = testEnv.authenticatedContext("user123").firestore();
  await assertFails(
    authedDb.collection("lobbies/bhp/crew_entries").add({
      reportingDate: "2026-10-25",
      offDate: "2026-10-25",
      offTime: "06:52",
      status: "Working",
      room: "Availed",
      userId: "different_user"
    })
  );
});

test("authenticated user can read crew entries", async () => {
  const authedDb = testEnv.authenticatedContext("user123").firestore();
  await assertSucceeds(authedDb.collection("lobbies/bhp/crew_entries").get());
});
