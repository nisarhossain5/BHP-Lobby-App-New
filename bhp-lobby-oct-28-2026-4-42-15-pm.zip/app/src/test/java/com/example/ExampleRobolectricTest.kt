package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("BHP Lobby", appName)
  }

  @Test
  fun `verify bhp_lobby html asset exists`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val assets = context.assets.list("") ?: emptyArray()
    assertTrue(assets.contains("bhp_lobby.html"))
  }
}
