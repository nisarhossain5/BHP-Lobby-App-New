package com.example

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Train
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.CrewPositionEntity
import com.example.data.local.SyncStatus
import com.example.data.sync.RoomToFirestoreSyncService
import com.example.ui.theme.MyApplicationTheme
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

private const val PREFS_NAME = "bhp_lobby_prefs"
private const val KEY_REMOTE_URL = "remote_url"
private const val KEY_USE_REMOTE = "use_remote"
private const val DEFAULT_REMOTE_URL = "https://ais-dev-mox2qta4tbjrs44vkq72ge-796902191671.asia-northeast1.run.app"
private const val LOCAL_ASSET_URL = "file:///android_asset/bhp_lobby.html"
private const val TAG = "BhpMainActivity"

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val syncService = RoomToFirestoreSyncService(applicationContext)

        setContent {
            MyApplicationTheme {
                BhpLobbyApp(prefs = prefs, syncService = syncService)
            }
        }
    }
}

/**
 * Checks whether the device currently has an active internet connection.
 */
fun isNetworkAvailable(context: Context): Boolean {
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
    val activeNetwork = cm.activeNetwork ?: return false
    val capabilities = cm.getNetworkCapabilities(activeNetwork) ?: return false
    return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
}

class AndroidWebAppInterface(
    private val context: Context,
    private val syncService: RoomToFirestoreSyncService,
    private val scope: CoroutineScope,
    private val getWebView: () -> WebView?
) {
    @JavascriptInterface
    fun onFileExport(data: String, filename: String, mimeType: String) {
        try {
            val exportDir = File(context.cacheDir, "exports")
            if (!exportDir.exists()) exportDir.mkdirs()
            val file = File(exportDir, filename)
            FileOutputStream(file).use { it.write(data.toByteArray(Charsets.UTF_8)) }

            val fileUri = androidx.core.content.FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType.ifEmpty { "text/plain" }
                putExtra(Intent.EXTRA_STREAM, fileUri)
                putExtra(Intent.EXTRA_SUBJECT, filename)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, "Save or Share $filename"))
        } catch (_: Exception) {
            try {
                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, data)
                    putExtra(Intent.EXTRA_TITLE, filename)
                }
                context.startActivity(Intent.createChooser(sendIntent, "Export $filename"))
            } catch (ex: Exception) {
                Toast.makeText(context, "Export error: ${ex.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    @JavascriptInterface
    fun printPage() {
        val webView = getWebView() ?: return
        webView.post {
            try {
                val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager
                val printAdapter = webView.createPrintDocumentAdapter("BHP_Lobby_Report")
                printManager?.print(
                    "BHP Lobby Crew Position Report",
                    printAdapter,
                    PrintAttributes.Builder().build()
                )
            } catch (e: Exception) {
                Toast.makeText(context, "Printing not supported: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    @JavascriptInterface
    fun onSyncEntries(entriesJson: String) {
        scope.launch(Dispatchers.IO) {
            try {
                val array = JSONArray(entriesJson)
                val list = mutableListOf<CrewPositionEntity>()
                val uid = Firebase.auth.currentUser?.uid ?: ""
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val id = obj.optString("id", "")
                    if (id.isNotBlank()) {
                        val pairsArray = obj.optJSONArray("pairs") ?: JSONArray()
                        list.add(
                            CrewPositionEntity(
                                id = id,
                                lobbyId = "bhp",
                                reportingDate = obj.optString("reportingDate", ""),
                                offDate = obj.optString("offDate", ""),
                                offTime = obj.optString("offTime", ""),
                                onDate = obj.optString("onDate", ""),
                                onTime = obj.optString("onTime", ""),
                                status = obj.optString("status", "Pending"),
                                room = obj.optString("room", "Availed"),
                                pairsJson = pairsArray.toString(),
                                userId = uid,
                                syncStatus = SyncStatus.PENDING_SYNC
                            )
                        )
                    }
                }
                if (list.isNotEmpty()) {
                    syncService.recordLocalEntries(list)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error processing entries from WebView", e)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BhpLobbyApp(
    prefs: SharedPreferences,
    syncService: RoomToFirestoreSyncService
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var useRemote by remember { mutableStateOf(prefs.getBoolean(KEY_USE_REMOTE, false)) }
    var remoteUrl by remember { mutableStateOf(prefs.getString(KEY_REMOTE_URL, "") ?: "") }

    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var isFallbackActive by remember { mutableStateOf(false) }
    var fallbackNotice by remember { mutableStateOf<String?>(null) }
    var isUsingRemoteContent by remember { mutableStateOf(false) }

    var isLoading by remember { mutableStateOf(false) }
    var loadProgress by remember { mutableIntStateOf(0) }

    var currentUser by remember { mutableStateOf(Firebase.auth.currentUser) }
    val syncState by syncService.syncState.collectAsStateWithLifecycle()

    var showSettingsDialog by remember { mutableStateOf(false) }
    var showInfoDialog by remember { mutableStateOf(false) }
    var showSyncDialog by remember { mutableStateOf(false) }
    var lastSentJson by remember { mutableStateOf("") }

    // Start background sync
    LaunchedEffect(currentUser) {
        syncService.startSync(this)
    }

    // Mirror Room updates into the WebView
    LaunchedEffect(Unit) {
        syncService.observeLocalCrewPositions().collectLatest { entities ->
            val wv = webViewRef ?: return@collectLatest
            if (entities.isNotEmpty()) {
                val jsonArray = JSONArray()
                for (entity in entities) {
                    val obj = JSONObject()
                    obj.put("id", entity.id)
                    obj.put("reportingDate", entity.reportingDate)
                    obj.put("offDate", entity.offDate)
                    obj.put("offTime", entity.offTime)
                    obj.put("onDate", entity.onDate)
                    obj.put("onTime", entity.onTime)
                    obj.put("status", entity.status)
                    obj.put("room", entity.room)
                    obj.put("pairs", try { JSONArray(entity.pairsJson) } catch (_: Exception) { JSONArray() })
                    jsonArray.put(obj)
                }
                val rawJson = jsonArray.toString()
                if (rawJson != lastSentJson) {
                    lastSentJson = rawJson
                    val encodedJson = JSONObject.quote(rawJson)
                    wv.post {
                        wv.evaluateJavascript(
                            "if (typeof window.syncFromNative === 'function') { window.syncFromNative($encodedJson); }",
                            null
                        )
                    }
                }
            }
        }
    }

    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { auth ->
            currentUser = auth.currentUser
        }
        Firebase.auth.addAuthStateListener(listener)
        onDispose {
            Firebase.auth.removeAuthStateListener(listener)
        }
    }

    BackHandler(enabled = true) {
        val wv = webViewRef
        if (wv != null && wv.canGoBack()) {
            wv.goBack()
        } else {
            wv?.evaluateJavascript("if (typeof showPage === 'function') { showPage('home'); }", null)
        }
    }

    // Determine target initial URL:
    // If remote is enabled and configured, check connectivity. If offline or unconfigured, load local fallback.
    val targetInitialUrl = remember(useRemote, remoteUrl) {
        val targetRemote = remoteUrl.trim()
        if (useRemote && targetRemote.isNotBlank() && targetRemote.startsWith("http")) {
            if (isNetworkAvailable(context)) {
                targetRemote
            } else {
                isFallbackActive = true
                fallbackNotice = "No internet connection detected. Loaded local offline asset."
                LOCAL_ASSET_URL
            }
        } else {
            LOCAL_ASSET_URL
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Train,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "BHP LOBBY",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (isUsingRemoteContent && !isFallbackActive) Icons.Default.CloudDone else Icons.Default.CloudOff,
                                    contentDescription = null,
                                    modifier = Modifier.size(12.dp),
                                    tint = if (isUsingRemoteContent && !isFallbackActive) Color(0xFF0D9488) else Color(0xFFD97706)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (isUsingRemoteContent && !isFallbackActive) "Remote Cloud UI" else "Offline Asset Fallback",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isUsingRemoteContent && !isFallbackActive) Color(0xFF0D9488) else Color(0xFFD97706),
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showSyncDialog = true },
                        modifier = Modifier.testTag("action_sync_dialog")
                    ) {
                        Icon(
                            imageVector = if (currentUser != null) Icons.Default.CloudSync else Icons.Default.AccountCircle,
                            contentDescription = "Cloud Sync & Auth",
                            tint = if (currentUser != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                        )
                    }
                    IconButton(
                        onClick = {
                            val targetRemote = remoteUrl.ifBlank { DEFAULT_REMOTE_URL }
                            if (useRemote && isNetworkAvailable(context)) {
                                isFallbackActive = false
                                fallbackNotice = null
                                webViewRef?.loadUrl(targetRemote)
                            } else {
                                webViewRef?.reload()
                            }
                        },
                        modifier = Modifier.testTag("action_refresh")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Reload"
                        )
                    }
                    IconButton(
                        onClick = { showSettingsDialog = true },
                        modifier = Modifier.testTag("action_cloud_settings")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Cloud,
                            contentDescription = "Cloud Interface Settings"
                        )
                    }
                    IconButton(
                        onClick = { showInfoDialog = true },
                        modifier = Modifier.testTag("action_info")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "Info & Architecture"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (isLoading) {
                LinearProgressIndicator(
                    progress = { loadProgress / 100f },
                    modifier = Modifier.fillMaxWidth().height(3.dp),
                    color = MaterialTheme.colorScheme.primary,
                )
            }

            // Fallback status banner
            AnimatedVisibility(
                visible = isFallbackActive,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(
                                imageVector = Icons.Default.CloudOff,
                                contentDescription = null,
                                modifier = Modifier.size(15.dp),
                                tint = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = fallbackNotice ?: "Offline mode active. Bundled local asset loaded.",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        }
                        TextButton(
                            onClick = {
                                val targetRemote = remoteUrl.ifBlank { DEFAULT_REMOTE_URL }
                                if (isNetworkAvailable(context)) {
                                    isFallbackActive = false
                                    fallbackNotice = null
                                    webViewRef?.loadUrl(targetRemote)
                                } else {
                                    Toast.makeText(context, "Internet still unavailable. Retaining offline version.", Toast.LENGTH_SHORT).show()
                                }
                            },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                            modifier = Modifier.height(26.dp)
                        ) {
                            Text("Retry Remote", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Box(modifier = Modifier.weight(1f)) {
                AndroidView(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("bhp_webview"),
                    factory = { ctx ->
                        createConfiguredWebView(
                            context = ctx,
                            initialUrl = targetInitialUrl,
                            syncService = syncService,
                            scope = coroutineScope,
                            onProgressChange = { progress, loading ->
                                loadProgress = progress
                                isLoading = loading
                            },
                            onSourceStatusChanged = { isRemote, url ->
                                isUsingRemoteContent = isRemote
                                if (isRemote) {
                                    isFallbackActive = false
                                    fallbackNotice = null
                                }
                            },
                            onFallbackToLocal = { reason ->
                                isFallbackActive = true
                                isUsingRemoteContent = false
                                fallbackNotice = "Remote unavailable ($reason). Local asset active."
                            },
                            getWebView = { webViewRef }
                        ).also { webViewRef = it }
                    },
                    update = { view ->
                        webViewRef = view
                    }
                )
            }
        }
    }

    if (showSyncDialog) {
        SyncAndAuthDialog(
            currentUserEmail = currentUser?.email,
            syncState = syncState,
            onDismiss = { showSyncDialog = false },
            onSignInClick = {
                handleGoogleSignIn(context, coroutineScope) {
                    currentUser = Firebase.auth.currentUser
                    coroutineScope.launch { syncService.syncNow() }
                }
            },
            onSignOutClick = {
                handleSignOut(context, coroutineScope) {
                    currentUser = null
                }
            },
            onSyncNowClick = {
                coroutineScope.launch {
                    val result = syncService.syncNow()
                    result.onSuccess { count ->
                        Toast.makeText(context, "Synced $count pending record(s) to Firestore", Toast.LENGTH_SHORT).show()
                    }.onFailure { err ->
                        Toast.makeText(context, "Sync failed: ${err.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        )
    }

    if (showSettingsDialog) {
        CloudSettingsDialog(
            currentRemoteUrl = remoteUrl,
            currentUseRemote = useRemote,
            onDismiss = { showSettingsDialog = false },
            onSave = { newUrl, enableRemote ->
                remoteUrl = newUrl.trim()
                useRemote = enableRemote
                prefs.edit()
                    .putString(KEY_REMOTE_URL, remoteUrl)
                    .putBoolean(KEY_USE_REMOTE, useRemote)
                    .apply()

                val targetUrl = if (useRemote && remoteUrl.isNotBlank()) remoteUrl else LOCAL_ASSET_URL
                if (useRemote && !isNetworkAvailable(context)) {
                    isFallbackActive = true
                    fallbackNotice = "No internet connection detected. Loaded local offline asset."
                    webViewRef?.loadUrl(LOCAL_ASSET_URL)
                } else {
                    isFallbackActive = false
                    fallbackNotice = null
                    webViewRef?.loadUrl(targetUrl)
                }
                showSettingsDialog = false
            }
        )
    }

    if (showInfoDialog) {
        InfoAndNextStepsDialog(
            onDismiss = { showInfoDialog = false },
            onOpenSettings = {
                showInfoDialog = false
                showSettingsDialog = true
            }
        )
    }
}

private fun handleGoogleSignIn(
    context: Context,
    scope: CoroutineScope,
    onSuccess: () -> Unit
) {
    val clientId = try {
        context.getString(R.string.default_web_client_id)
    } catch (_: Exception) {
        Toast.makeText(context, "Google Client ID missing from google-services.json", Toast.LENGTH_LONG).show()
        return
    }

    val credentialManager = CredentialManager.create(context)
    val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
    val request = GetCredentialRequest.Builder().addCredentialOption(signInOption).build()

    scope.launch {
        try {
            val result = credentialManager.getCredential(context as Activity, request)
            val credential = result.credential
            if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
                val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
                Firebase.auth.signInWithCredential(authCredential).await()
                Toast.makeText(context, "Signed in as ${Firebase.auth.currentUser?.email}", Toast.LENGTH_SHORT).show()
                onSuccess()
            }
        } catch (e: GetCredentialCancellationException) {
            Log.w(TAG, "Sign-in cancelled: ${e.message}")
        } catch (e: Exception) {
            Log.e(TAG, "Google Sign-In failed", e)
            Toast.makeText(context, "Sign-In error: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }
}

private fun handleSignOut(
    context: Context,
    scope: CoroutineScope,
    onComplete: () -> Unit
) {
    Firebase.auth.signOut()
    val credentialManager = CredentialManager.create(context)
    scope.launch {
        try {
            credentialManager.clearCredentialState(ClearCredentialStateRequest())
        } catch (_: Exception) {}
        onComplete()
        Toast.makeText(context, "Signed out", Toast.LENGTH_SHORT).show()
    }
}

@Composable
fun SyncAndAuthDialog(
    currentUserEmail: String?,
    syncState: com.example.data.sync.SyncServiceState,
    onDismiss: () -> Unit,
    onSignInClick: () -> Unit,
    onSignOutClick: () -> Unit,
    onSyncNowClick: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "Room-to-Firestore Sync",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(12.dp))

                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (currentUserEmail != null) Color(0xFFECFDF5) else Color(0xFFFFFBEB)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = if (currentUserEmail != null) "Authorized Supervisor" else "Authentication Required",
                            fontWeight = FontWeight.Bold,
                            color = if (currentUserEmail != null) Color(0xFF047857) else Color(0xFFB45309),
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = currentUserEmail ?: "Sign in with your Google account to enable cloud synchronization across multiple phones.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Pending Cloud Sync",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.outline
                        )
                        Text(
                            text = "${syncState.pendingCount} record(s)",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }

                    Button(
                        onClick = onSyncNowClick,
                        enabled = !syncState.isSyncing,
                        modifier = Modifier.testTag("btn_sync_now")
                    ) {
                        if (syncState.isSyncing) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color = MaterialTheme.colorScheme.onPrimary,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Icon(imageVector = Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Sync Now")
                        }
                    }
                }

                if (syncState.lastError != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = syncState.lastError ?: "",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                if (currentUserEmail == null) {
                    Button(
                        onClick = onSignInClick,
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        modifier = Modifier.fillMaxWidth().testTag("btn_google_signin")
                    ) {
                        Icon(imageVector = Icons.Default.AccountCircle, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Sign in with Google")
                    }
                } else {
                    OutlinedButton(
                        onClick = onSignOutClick,
                        modifier = Modifier.fillMaxWidth().testTag("btn_google_signout")
                    ) {
                        Text("Sign Out")
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("Close")
                }
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
private fun createConfiguredWebView(
    context: Context,
    initialUrl: String,
    syncService: RoomToFirestoreSyncService,
    scope: CoroutineScope,
    onProgressChange: (Int, Boolean) -> Unit,
    onSourceStatusChanged: (Boolean, String) -> Unit,
    onFallbackToLocal: (String) -> Unit,
    getWebView: () -> WebView?
): WebView {
    return WebView(context).apply {
        // Use software layer to prevent Chromium GPU compositor from attempting to access
        // non-existent hardware rendernodes in containerized/virtualized environments
        setLayerType(android.view.View.LAYER_TYPE_SOFTWARE, null)

        settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                safeBrowsingEnabled = false
            }
        }

        addJavascriptInterface(
            AndroidWebAppInterface(context, syncService, scope, getWebView),
            "AndroidBridge"
        )

        webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                onProgressChange(newProgress, newProgress < 100)
            }

            override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                AlertDialog.Builder(context)
                    .setTitle("BHP Lobby")
                    .setMessage(message ?: "")
                    .setPositiveButton("OK") { _, _ -> result?.confirm() }
                    .setOnCancelListener { result?.cancel() }
                    .show()
                return true
            }

            override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                AlertDialog.Builder(context)
                    .setTitle("Confirm")
                    .setMessage(message ?: "")
                    .setPositiveButton("OK") { _, _ -> result?.confirm() }
                    .setNegativeButton("Cancel") { _, _ -> result?.cancel() }
                    .setOnCancelListener { result?.cancel() }
                    .show()
                return true
            }

            override fun onJsPrompt(
                view: WebView?,
                url: String?,
                message: String?,
                defaultValue: String?,
                result: JsPromptResult?
            ): Boolean {
                val input = EditText(context).apply {
                    setText(defaultValue ?: "")
                    setSelection(text.length)
                }
                AlertDialog.Builder(context)
                    .setTitle(message ?: "Enter Value")
                    .setView(input)
                    .setPositiveButton("OK") { _, _ -> result?.confirm(input.text.toString()) }
                    .setNegativeButton("Cancel") { _, _ -> result?.cancel() }
                    .setOnCancelListener { result?.cancel() }
                    .show()
                return true
            }
        }

        webViewClient = object : WebViewClient() {
            // Modern API 23+ main-frame connection error handler
            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                super.onReceivedError(view, request, error)
                if (request?.isForMainFrame == true) {
                    val failingUrl = request.url?.toString() ?: ""
                    if (!failingUrl.startsWith("file:///android_asset/")) {
                        val desc = error?.description?.toString() ?: "Connection failed"
                        Log.w(TAG, "Main frame error on $failingUrl: $desc. Triggering local asset fallback.")
                        onFallbackToLocal(desc)
                        view?.loadUrl(LOCAL_ASSET_URL)
                    }
                }
            }

            // HTTP 4xx/5xx error handler
            override fun onReceivedHttpError(
                view: WebView?,
                request: WebResourceRequest?,
                errorResponse: WebResourceResponse?
            ) {
                super.onReceivedHttpError(view, request, errorResponse)
                if (request?.isForMainFrame == true) {
                    val code = errorResponse?.statusCode ?: 200
                    val failingUrl = request.url?.toString() ?: ""
                    if (code >= 400 && !failingUrl.startsWith("file:///android_asset/")) {
                        Log.w(TAG, "HTTP $code on $failingUrl. Triggering local asset fallback.")
                        onFallbackToLocal("HTTP Error $code")
                        view?.loadUrl(LOCAL_ASSET_URL)
                    }
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                if (url != null) {
                    val isRemote = !url.startsWith("file:///android_asset/")
                    onSourceStatusChanged(isRemote, url)
                }
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                if (url.startsWith("http://") || url.startsWith("https://") || url.startsWith("file://")) {
                    return false
                }
                try {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                    context.startActivity(intent)
                    return true
                } catch (_: Exception) {
                    return false
                }
            }
        }

        loadUrl(initialUrl)
    }
}

@Composable
fun CloudSettingsDialog(
    currentRemoteUrl: String,
    currentUseRemote: Boolean,
    onDismiss: () -> Unit,
    onSave: (String, Boolean) -> Unit
) {
    var urlInput by remember { mutableStateOf(currentRemoteUrl) }
    var remoteEnabled by remember { mutableStateOf(currentUseRemote) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "Cloud-Hosted Live Interface",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "When enabled, the app loads your remote web interface. Any updates published online take effect immediately for all users without reinstalling the APK. If internet is down, it falls back seamlessly to the local bundled asset.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = urlInput,
                    onValueChange = { urlInput = it },
                    label = { Text("Cloud Hosted Web URL") },
                    placeholder = { Text(DEFAULT_REMOTE_URL) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_remote_url")
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Switch(
                        checked = remoteEnabled,
                        onCheckedChange = { remoteEnabled = it },
                        modifier = Modifier.testTag("switch_use_remote")
                    )
                    Text(
                        text = if (remoteEnabled) "Enabled: Load live remote UI" else "Disabled: Use bundled offline HTML",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "Automatic Offline Fallback",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "The WebView monitors connectivity and main-frame load failures. If internet is lost or the remote host returns an error, it immediately transitions to file:///android_asset/bhp_lobby.html.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedButton(
                        onClick = {
                            onSave(urlInput, remoteEnabled)
                        },
                        modifier = Modifier.testTag("btn_save_cloud_settings")
                    ) {
                        Text("Apply & Reload")
                    }
                }
            }
        }
    }
}

@Composable
fun InfoAndNextStepsDialog(
    onDismiss: () -> Unit,
    onOpenSettings: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "BHP Lobby Setup & Status",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "1. Remote Web Content & Offline Fallback:",
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "• The WebView loads the remote cloud-hosted HTML by default.\n• If internet is disconnected or the server is unreachable, it automatically falls back to file:///android_asset/bhp_lobby.html without showing browser error pages.\n• Tap 'Retry Remote' on the top banner anytime connectivity returns.",
                    style = MaterialTheme.typography.bodySmall
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "2. Room-to-Firestore Synchronization Service:",
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "• Local Room database (`bhp_lobby_room.db`) stores entries locally.\n• RoomToFirestoreSyncService pushes pending records to Cloud Firestore (`/lobbies/bhp/crew_entries`) when signed in with Google.\n• Real-time snapshot listener mirrors changes from other supervisors back into Room and updates the UI.",
                    style = MaterialTheme.typography.bodySmall
                )

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Close")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedButton(onClick = onOpenSettings) {
                        Text("Cloud Settings")
                    }
                }
            }
        }
    }
}
