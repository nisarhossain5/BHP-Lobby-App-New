package com.example.data.remote

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class CrewPairDto(
    val category: String = "",
    val hq: String = ""
)

@IgnoreExtraProperties
data class CrewPositionDto(
    @DocumentId
    val id: String = "",
    val lobbyId: String = "bhp",
    val reportingDate: String = "",
    val offDate: String = "",
    val offTime: String = "",
    val onDate: String = "",
    val onTime: String = "",
    val status: String = "Pending",
    val room: String = "Availed",
    val pairs: List<Map<String, String>> = emptyList(),
    val userId: String = "",
    val userEmail: String = "",
    @ServerTimestamp
    val createdAt: Timestamp? = null,
    @ServerTimestamp
    val updatedAt: Timestamp? = null
)
