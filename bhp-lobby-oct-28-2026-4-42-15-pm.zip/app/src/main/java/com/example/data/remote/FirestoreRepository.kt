package com.example.data.remote

import android.content.Context
import com.example.R
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class FirestoreRepository(
    val db: FirebaseFirestore,
    val lobbyId: String = "bhp"
) {
    constructor(context: Context, lobbyId: String = "bhp") : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        lobbyId
    )

    private val auth = Firebase.auth

    fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    fun isUserSignedIn(): Boolean = auth.currentUser != null

    fun getCurrentUserEmail(): String? = auth.currentUser?.email

    fun crewCollection() =
        db.collection("lobbies").document(lobbyId).collection("crew_entries")

    fun observeLobbyEntries(): Flow<List<CrewPositionDto>> = flow {
        emitAll(
            crewCollection()
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(CrewPositionDto::class.java)
                }
        )
    }

    suspend fun upsertCrewEntry(dto: CrewPositionDto) {
        val uid = requireUserId()
        val docRef = if (dto.id.isNotBlank()) crewCollection().document(dto.id) else crewCollection().document()
        val data = hashMapOf<String, Any?>(
            "id" to docRef.id,
            "lobbyId" to lobbyId,
            "reportingDate" to dto.reportingDate,
            "offDate" to dto.offDate,
            "offTime" to dto.offTime,
            "onDate" to dto.onDate,
            "onTime" to dto.onTime,
            "status" to dto.status,
            "room" to dto.room,
            "pairs" to dto.pairs,
            "userId" to uid,
            "userEmail" to (auth.currentUser?.email ?: ""),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (dto.createdAt == null) {
            data["createdAt"] = FieldValue.serverTimestamp()
        }
        docRef.set(data).await()
    }

    suspend fun deleteCrewEntry(id: String) {
        require(id.isNotBlank()) { "ID must not be blank" }
        crewCollection().document(id).delete().await()
    }
}
