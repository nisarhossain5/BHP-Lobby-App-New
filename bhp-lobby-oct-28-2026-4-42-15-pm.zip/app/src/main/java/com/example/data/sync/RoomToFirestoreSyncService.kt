package com.example.data.sync

import android.content.Context
import android.util.Log
import com.example.data.local.AppDatabase
import com.example.data.local.CrewPositionDao
import com.example.data.local.CrewPositionEntity
import com.example.data.local.SyncStatus
import com.example.data.remote.CrewPositionDto
import com.example.data.remote.FirestoreRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

private const val TAG = "BhpSyncService"

data class SyncServiceState(
    val isSyncing: Boolean = false,
    val pendingCount: Int = 0,
    val lastSyncTime: Long? = null,
    val lastError: String? = null,
    val userEmail: String? = null
)

class RoomToFirestoreSyncService(
    private val context: Context,
    private val dao: CrewPositionDao = AppDatabase.getInstance(context).crewPositionDao(),
    private val firestoreRepo: FirestoreRepository = FirestoreRepository(context)
) {
    private val _syncState = MutableStateFlow(SyncServiceState())
    val syncState: StateFlow<SyncServiceState> = _syncState.asStateFlow()

    private var observationJob: Job? = null

    fun isUserSignedIn(): Boolean = firestoreRepo.isUserSignedIn()

    fun getCurrentUserEmail(): String? = firestoreRepo.getCurrentUserEmail()

    /**
     * Start background real-time synchronization between Room and Cloud Firestore.
     */
    fun startSync(scope: CoroutineScope) {
        observationJob?.cancel()
        observationJob = scope.launch(Dispatchers.IO) {
            updatePendingCount()

            // 1. Initial push of any pending local entries
            syncLocalToCloudInternal()

            // 2. Continuous real-time pull from Firestore to Room
            if (firestoreRepo.isUserSignedIn()) {
                try {
                    firestoreRepo.observeLobbyEntries().collectLatest { cloudEntries ->
                        mirrorCloudToLocal(cloudEntries)
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Log.e(TAG, "Error in continuous Firestore observation", e)
                    _syncState.value = _syncState.value.copy(
                        lastError = e.localizedMessage ?: "Failed observing Firestore"
                    )
                }
            }
        }
    }

    /**
     * Trigger immediate manual sync of local pending records to Cloud Firestore.
     */
    suspend fun syncNow(): Result<Int> = withContext(Dispatchers.IO) {
        syncLocalToCloudInternal()
    }

    /**
     * Add a new crew record locally to Room and schedule cloud sync.
     */
    suspend fun recordLocalEntry(entity: CrewPositionEntity) = withContext(Dispatchers.IO) {
        dao.insert(entity)
        updatePendingCount()
        if (firestoreRepo.isUserSignedIn()) {
            syncLocalToCloudInternal()
        }
    }

    /**
     * Add multiple crew records locally to Room and schedule cloud sync.
     */
    suspend fun recordLocalEntries(entities: List<CrewPositionEntity>) = withContext(Dispatchers.IO) {
        if (entities.isNotEmpty()) {
            dao.insertAll(entities)
            updatePendingCount()
            if (firestoreRepo.isUserSignedIn()) {
                syncLocalToCloudInternal()
            }
        }
    }

    /**
     * Convert Room entity to Firestore DTO and upload.
     */
    private suspend fun syncLocalToCloudInternal(): Result<Int> {
        if (!firestoreRepo.isUserSignedIn()) {
            val pending = dao.getPendingSync().size
            _syncState.value = _syncState.value.copy(
                isSyncing = false,
                pendingCount = pending,
                lastError = "Google Sign-In required to sync records to Firestore."
            )
            return Result.failure(IllegalStateException("User not signed in with Google"))
        }

        _syncState.value = _syncState.value.copy(
            isSyncing = true,
            userEmail = firestoreRepo.getCurrentUserEmail(),
            lastError = null
        )

        var syncedCount = 0
        val pendingEntities = dao.getPendingSync()

        for (entity in pendingEntities) {
            try {
                val pairsList = parsePairsJson(entity.pairsJson)
                val dto = CrewPositionDto(
                    id = entity.id,
                    lobbyId = entity.lobbyId,
                    reportingDate = entity.reportingDate,
                    offDate = entity.offDate,
                    offTime = entity.offTime,
                    onDate = entity.onDate,
                    onTime = entity.onTime,
                    status = entity.status,
                    room = entity.room,
                    pairs = pairsList,
                    userId = firestoreRepo.requireUserId(),
                    userEmail = firestoreRepo.getCurrentUserEmail() ?: ""
                )

                firestoreRepo.upsertCrewEntry(dto)
                dao.updateSyncStatus(entity.id, SyncStatus.SYNCED, null)
                syncedCount++
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Failed to sync entry ${entity.id} to Firestore", e)
                dao.updateSyncStatus(entity.id, SyncStatus.FAILED, e.localizedMessage)
                _syncState.value = _syncState.value.copy(
                    lastError = "Sync error: ${e.localizedMessage}"
                )
            }
        }

        updatePendingCount()
        _syncState.value = _syncState.value.copy(
            isSyncing = false,
            lastSyncTime = System.currentTimeMillis()
        )
        return Result.success(syncedCount)
    }

    /**
     * Mirror remote Firestore entries into the local Room database.
     */
    private suspend fun mirrorCloudToLocal(cloudEntries: List<CrewPositionDto>) {
        for (dto in cloudEntries) {
            val existing = dao.getById(dto.id)
            // If local record is pending sync, do not overwrite uncommitted local edits
            if (existing != null && existing.syncStatus == SyncStatus.PENDING_SYNC) {
                continue
            }

            val pairsJsonString = serializePairsList(dto.pairs)
            val entity = CrewPositionEntity(
                id = dto.id,
                lobbyId = dto.lobbyId,
                reportingDate = dto.reportingDate,
                offDate = dto.offDate,
                offTime = dto.offTime,
                onDate = dto.onDate,
                onTime = dto.onTime,
                status = dto.status,
                room = dto.room,
                pairsJson = pairsJsonString,
                userId = dto.userId,
                syncStatus = SyncStatus.SYNCED,
                lastSyncError = null,
                createdAt = dto.createdAt?.toDate()?.time ?: System.currentTimeMillis(),
                updatedAt = dto.updatedAt?.toDate()?.time ?: System.currentTimeMillis()
            )
            dao.insert(entity)
        }
        updatePendingCount()
    }

    private suspend fun updatePendingCount() {
        val count = dao.getPendingSync().size
        _syncState.value = _syncState.value.copy(pendingCount = count)
    }

    fun observeLocalCrewPositions(): Flow<List<CrewPositionEntity>> = dao.observeAll()

    private fun parsePairsJson(json: String): List<Map<String, String>> {
        val result = mutableListOf<Map<String, String>>()
        if (json.isBlank()) return result
        try {
            val array = JSONArray(json)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                result.add(
                    mapOf(
                        "category" to obj.optString("category", ""),
                        "hq" to obj.optString("hq", "")
                    )
                )
            }
        } catch (_: Exception) {}
        return result
    }

    private fun serializePairsList(pairs: List<Map<String, String>>): String {
        val array = JSONArray()
        for (pair in pairs) {
            val obj = JSONObject()
            obj.put("category", pair["category"] ?: "")
            obj.put("hq", pair["hq"] ?: "")
            array.put(obj)
        }
        return array.toString()
    }
}
