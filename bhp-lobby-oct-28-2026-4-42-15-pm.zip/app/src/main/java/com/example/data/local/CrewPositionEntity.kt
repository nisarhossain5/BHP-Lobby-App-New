package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class SyncStatus {
    PENDING_SYNC,
    SYNCED,
    FAILED
}

@Entity(tableName = "crew_positions")
data class CrewPositionEntity(
    @PrimaryKey
    val id: String,
    val lobbyId: String = "bhp",
    val reportingDate: String,
    val offDate: String,
    val offTime: String,
    val onDate: String = "",
    val onTime: String = "",
    val status: String,
    val room: String,
    val pairsJson: String,
    val userId: String = "",
    val syncStatus: SyncStatus = SyncStatus.PENDING_SYNC,
    val lastSyncError: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
