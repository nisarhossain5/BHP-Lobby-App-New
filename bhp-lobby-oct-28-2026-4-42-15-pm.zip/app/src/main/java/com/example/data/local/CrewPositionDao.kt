package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface CrewPositionDao {

    @Query("SELECT * FROM crew_positions ORDER BY reportingDate DESC, offTime DESC")
    fun observeAll(): Flow<List<CrewPositionEntity>>

    @Query("SELECT * FROM crew_positions WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): CrewPositionEntity?

    @Query("SELECT * FROM crew_positions WHERE syncStatus = :status")
    suspend fun getBySyncStatus(status: SyncStatus): List<CrewPositionEntity>

    @Query("SELECT * FROM crew_positions WHERE syncStatus = 'PENDING_SYNC'")
    suspend fun getPendingSync(): List<CrewPositionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: CrewPositionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(entities: List<CrewPositionEntity>)

    @Update
    suspend fun update(entity: CrewPositionEntity)

    @Query("UPDATE crew_positions SET syncStatus = :newStatus, lastSyncError = :error, updatedAt = :timestamp WHERE id = :id")
    suspend fun updateSyncStatus(id: String, newStatus: SyncStatus, error: String?, timestamp: Long = System.currentTimeMillis())

    @Delete
    suspend fun delete(entity: CrewPositionEntity)

    @Query("DELETE FROM crew_positions WHERE id = :id")
    suspend fun deleteById(id: String)
}
